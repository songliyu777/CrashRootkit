#pragma once

#define _CRD_
#include "Transfer.h"

NTSTATUS SetKeException(PTransferMsg msg);

NTSTATUS DoKeExceptionHook();

NTSTATUS DoCommonDispatchExceptionHook();

NTSTATUS GetKiUserExceptionDispatcher_XP();

NTSTATUS GetKiUserExceptionDispatcher_WIN7();

VOID SetKiUserExceptionDispatcherAddress(ULONG_PTR BaseAddress);

ULONG_PTR GetKiUserExceptionDispatcherAddress();