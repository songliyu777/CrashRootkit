#ifdef __cplusplus
extern "C" {
#endif
#include <ntddk.h>
#include <string.h>
#ifdef __cplusplus
}; // extern "C"
#endif

#include "KeSysFun.h"
#include "Relocate.h"
#include "CRD_KeException.h"
#include "CRD_Hook.h"
#include "Log.h"
#include "CRD_ProtectTools.h"
#include "CRD_BsodHook.h"
#include "Platform.h"

ULONG_PTR OriginalKiUserExceptionDispatcher = 0; 
ULONG_PTR KiUserExceptionDispatcherAddress_Proxy = 0;
ULONG_PTR KiExceptionExitAddress = 0;

BOOLEAN NeedChangeKiUserExceptionDispatcher()
{
	KPROCESSOR_MODE  mode;
	mode = ExGetPreviousMode();
	if (mode == UserMode)
	{
		if(IsTargetProcessId(PsGetCurrentProcessId()) && OriginalKiUserExceptionDispatcher)
		{
			return TRUE;
		}
	}
	return FALSE;
}

//VOID __declspec(naked) KiDispatchException_Proxy_XP()
//{
//	_asm
//	{
//		push ebx
//		push ecx
//		push edx
//		push esi
//		push edi
//		push esp
//		push ebp
//		pushfd
//		call NeedChangeKiUserExceptionDispatcher
//		cmp al,0
//		mov eax,OriginalKiUserExceptionDispatcher
//		je NO_CHANGE_EXCEPTION_XP
//		mov eax,KiUserExceptionDispatcherAddress_Proxy
//NO_CHANGE_EXCEPTION_XP:
//		popfd
//		pop ebp
//		pop esp
//		pop edi
//		pop esi
//		pop edx
//		pop ecx
//		pop ebx
//		mov dword ptr [ebx+68h],eax //eax: ntdll!KiUserExceptionDispatcher
//		or  dword ptr [ebp-4],0FFFFFFFFh
//		jmp OrignalKiDispatchException_Jmp
//	}
//}
//xp
//804ff7a4 8ac8            mov     cl,al
//804ff7a6 f6d9            neg     cl
//804ff7a8 1bc9            sbb     ecx,ecx
//804ff7aa 83e103          and     ecx,3
//804ff7ad 83c120          add     ecx,20h
//804ff7b0 894b38          mov     dword ptr [ebx+38h],ecx
//804ff7b3 894b34          mov     dword ptr [ebx+34h],ecx
//804ff7b6 f6d8            neg     al
//804ff7b8 1bc0            sbb     eax,eax
//804ff7ba 83e003          and     eax,3
//804ff7bd 83c038          add     eax,38h
//804ff7c0 894350          mov     dword ptr [ebx+50h],eax
//804ff7c3 83633000        and     dword ptr [ebx+30h],0
//804ff7c7 a170d65580      mov     eax,dword ptr [nt!KeUserExceptionDispatcher (8055d670)]
//804ff7cc 894368          mov     dword ptr [ebx+68h],eax
//804ff7cf 834dfcff        or      dword ptr [ebp-4],0FFFFFFFFh

//xp CommonDispatchException
//80543186 83e001          and     eax,1
//80543189 6a01            push    1
//8054318b 50              push    eax
//8054318c 55              push    ebp
//8054318d 6a00            push    0
//8054318f 51              push    ecx
//80543190 e82dc3fbff      call    nt!KiDispatchException (804ff4c2)
//80543195 8be5            mov     esp,ebp
//80543197 e920feffff      jmp     nt!KiExceptionExit (80542fbc)

//win7 CommonDispatchException
//83c8ae67 83e001          and     eax,1
//83c8ae6a 6a01            push    1
//83c8ae6c 50              push    eax
//83c8ae6d 55              push    ebp
//83c8ae6e 6a00            push    0
//83c8ae70 51              push    ecx
//83c8ae71 e86a600700      call    nt!KiDispatchException (83d00ee0)
//83c8ae76 8be5            mov     esp,ebp
//83c8ae78 e91bfeffff      jmp     nt!KiExceptionExit (83c8ac98)

VOID DispatchTrapFrame(PKTRAP_FRAME TrapFrame)
{
	if(NeedChangeKiUserExceptionDispatcher())
	{
		if(TrapFrame->Eip==OriginalKiUserExceptionDispatcher)
		{
			TrapFrame->Eip = KiUserExceptionDispatcherAddress_Proxy;
		} 
	}
}

VOID  __declspec(naked) CommonDispatchException_Proxy()
{
	_asm
	{
		pushad
		pushfd
		push ebp
		call DispatchTrapFrame
		popfd
		popad
		mov esp,ebp
		mov eax,KiExceptionExitAddress
		jmp eax
	}
}

NTSTATUS DoCommonDispatchExceptionHook()
{
	NTSTATUS status = STATUS_UNSUCCESSFUL;
	SYSTEM_VERSION version = GetSystemVersion();
	switch(version)
	{
	case WINDOWSXP:
		status = GetKiUserExceptionDispatcher_XP();
		break;
	case WINDOWS7:
		status = GetKiUserExceptionDispatcher_WIN7();
		break;
	}
	
	if(!NT_SUCCESS(status))
		return STATUS_UNSUCCESSFUL;
	ULONG_PTR maddress = 0,offset = 0;
	ULONG_PTR hookstartadr = 0;
	ULONG_PTR KiExceptionExit_adr = 0;
	BYTE KeyWords[11] = {0x83,0xe0,0x01,0x6a,0x01,0x50,0x55,0x6a,0x00,0x51,0xe8};
	ULONG_PTR BaseAddress = GetNtKrBase();
	__try
	{
		maddress = FindMemoryAddress((ULONG_PTR)GetMemoryModuleNtKr()->codeBase,(ULONG_PTR)GetMemoryModuleNtKr()->codeBase + GetMemoryModuleNtKr()->SizeOfImage,KeyWords,11,FALSE);
		if(maddress)
		{
			offset = maddress - (ULONG_PTR)GetMemoryModuleNtKr()->codeBase;
			hookstartadr = BaseAddress + offset + 15;
			if(RtlCompareMemory((PVOID)hookstartadr,(PVOID)(maddress + 15),5)!=5)
			{
				PrintLog(L"Find CommonDispatchException Inline Hook \r\n");
				return STATUS_UNSUCCESSFUL;
			}
			KiExceptionExitAddress = hookstartadr + 7 + *PULONG_PTR(hookstartadr + 3);
			KdPrint(("CommonDispatchExceptionHookAddress %p KiExceptionExitAddress %p\r\n",hookstartadr,KiExceptionExitAddress));
			PrintLog(L"CommonDispatchExceptionHookAddress %p KiExceptionExitAddress %p\r\n",hookstartadr,KiExceptionExitAddress);
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		KdPrint(("CommonDispatchExceptionHook exception \r\n"));
		PrintLog(L"CommonDispatchExceptionHook exception \r\n");
		return STATUS_UNSUCCESSFUL;
	}
	if(!SetDynamicInLineHook("CommonDispatchException",hookstartadr,5,(ULONG_PTR)CommonDispatchException_Proxy,INLINE_HOOK_TYPE_JMP))
	{
		return STATUS_UNSUCCESSFUL;
	}
	return STATUS_SUCCESS;
}

NTSTATUS GetKiUserExceptionDispatcher_XP()
{
	ULONG_PTR maddress = 0,offset = 0;
	ULONG_PTR hookstartadr = 0;
	BYTE KeyWords[35] = {0x8a,0xc8,0xf6,0xd9,0x1b,0xc9,0x83,0xe1,0x03,0x83,
						 0xc1,0x20,0x89,0x4b,0x38,0x89,0x4b,0x34,0xf6,0xd8,
						 0x1b,0xc0,0x83,0xe0,0x03,0x83,0xc0,0x38,0x89,0x43,
						 0x50,0x83,0x63,0x30,0x0};
	ULONG_PTR BaseAddress = GetNtKrBase();
	__try
	{
		maddress = FindMemoryAddress((ULONG_PTR)GetMemoryModuleNtKr()->codeBase,(ULONG_PTR)GetMemoryModuleNtKr()->codeBase + GetMemoryModuleNtKr()->SizeOfImage,KeyWords,35,FALSE);
		if(maddress)
		{
			offset = maddress - (ULONG_PTR)GetMemoryModuleNtKr()->codeBase;
			hookstartadr = BaseAddress + offset + 40;
			if(RtlCompareMemory((PVOID)hookstartadr,(PVOID)(maddress + 40),5)!=5)
			{
				PrintLog(L"Find KiDispatchException Inline Hook \r\n");
				return STATUS_UNSUCCESSFUL;
			}
			ULONG_PTR value = *PULONG_PTR(hookstartadr - 4);
			if(!MmIsAddressValid((PVOID)value))
			{
				return STATUS_UNSUCCESSFUL;
			}
			OriginalKiUserExceptionDispatcher = *PULONG_PTR(value);
			KdPrint(("KiDispatchExceptionHookAddress %p \r\n",hookstartadr));
			PrintLog(L"KiDispatchExceptionHookAddress %p \r\n",hookstartadr);
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		KdPrint(("GetKiUserExceptionDispatcher exception \r\n"));
		PrintLog(L"GetKiUserExceptionDispatcher exception \r\n");
		return STATUS_UNSUCCESSFUL;
	}
	return STATUS_SUCCESS;
}

//VOID __declspec(naked) KiDispatchException_Proxy_WIN7()
//{
//	_asm
//	{
//		push ebx
//			push ecx
//			push edx
//			push esi
//			push edi
//			push esp
//			push ebp
//			pushfd
//			call NeedChangeKiUserExceptionDispatcher
//			cmp al,0
//			mov eax,OriginalKiUserExceptionDispatcher
//			je NO_CHANGE_EXCEPTION_WIN7
//			mov eax,KiUserExceptionDispatcherAddress_Proxy
//NO_CHANGE_EXCEPTION_WIN7:
//		popfd
//			pop ebp
//			pop esp
//			pop edi
//			pop esi
//			pop edx
//			pop ecx
//			pop ebx
//			mov dword ptr [esi+68h],eax
//			mov dword ptr [ebp-4],0FFFFFFFEh
//			jmp OrignalKiDispatchException_Jmp
//	}
//}
//win7
//83d0128e 83e0fd          and     eax,0FFFFFFFDh
//83d01291 83c023          add     eax,23h
//83d01294 894638          mov     dword ptr [esi+38h],eax
//83d01297 894634          mov     dword ptr [esi+34h],eax
//83d0129a 33c0            xor     eax,eax
//83d0129c 384514          cmp     byte ptr [ebp+14h],al
//83d0129f 0f95c0          setne   al
//83d012a2 48              dec     eax
//83d012a3 83e0fd          and     eax,0FFFFFFFDh
//83d012a6 83c03b          add     eax,3Bh
//83d012a9 894650          mov     dword ptr [esi+50h],eax
//83d012ac 83663000        and     dword ptr [esi+30h],0
//83d012b0 a1e45adb83      mov     eax,dword ptr [nt!KeUserExceptionDispatcher (83db5ae4)]
//83d012b5 894668          mov     dword ptr [esi+68h],eax
//83d012b8 c745fcfeffffff  mov     dword ptr [ebp-4],0FFFFFFFEh

NTSTATUS GetKiUserExceptionDispatcher_WIN7()
{
	ULONG_PTR maddress = 0,offset = 0;
	ULONG_PTR hookstartadr = 0;
	BYTE KeyWords[34] = {0x83,0xe0,0xfd,0x83,0xc0,0x23,0x89,0x46,0x38,0x89,
						 0x46,0x34,0x33,0xc0,0x38,0x45,0x14,0x0f,0x95,0xc0,
						 0x48,0x83,0xe0,0xfd,0x83,0xc0,0x3b,0x89,0x46,0x50,
						 0x83,0x66,0x30,0x00};
	ULONG_PTR BaseAddress = GetNtKrBase();
	__try
	{
		maddress = FindMemoryAddress((ULONG_PTR)GetMemoryModuleNtKr()->codeBase,(ULONG_PTR)GetMemoryModuleNtKr()->codeBase + GetMemoryModuleNtKr()->SizeOfImage,KeyWords,34,FALSE);
		if(maddress)
		{
			offset = maddress - (ULONG_PTR)GetMemoryModuleNtKr()->codeBase;
			hookstartadr = BaseAddress + offset + 39;
			if(RtlCompareMemory((PVOID)hookstartadr,(PVOID)(maddress + 39),5)!=5)
			{
				PrintLog(L"Find KiDispatchException Inline Hook \r\n");
				return STATUS_UNSUCCESSFUL;
			}
			ULONG_PTR value = *PULONG_PTR(hookstartadr - 4);
			if(!MmIsAddressValid((PVOID)value))
			{
				return STATUS_UNSUCCESSFUL;
			}
			OriginalKiUserExceptionDispatcher = *PULONG_PTR(value);
			KdPrint(("KiDispatchExceptionHookAddress %p \r\n",hookstartadr));
			PrintLog(L"KiDispatchExceptionHookAddress %p \r\n",hookstartadr);
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		KdPrint(("DoKiDispatchExceptionHook exception \r\n"));
		PrintLog(L"DoKiDispatchExceptionHook exception \r\n");
		return STATUS_UNSUCCESSFUL;
	}
	return STATUS_SUCCESS;
}

VOID SetKiUserExceptionDispatcherAddress(ULONG_PTR BaseAddress)
{
	KiUserExceptionDispatcherAddress_Proxy = BaseAddress;
}

ULONG_PTR GetKiUserExceptionDispatcherAddress()
{
	return KiUserExceptionDispatcherAddress_Proxy;
}

NTSTATUS DoKeExceptionHook()
{
	return DoCommonDispatchExceptionHook();
}

NTSTATUS SetKeException(PTransferMsg msg)
{
	ULONG_PTR ulBaseAddr = *PULONG_PTR(msg->buff);
	SetKiUserExceptionDispatcherAddress(ulBaseAddr);
	return STATUS_SUCCESS;
}